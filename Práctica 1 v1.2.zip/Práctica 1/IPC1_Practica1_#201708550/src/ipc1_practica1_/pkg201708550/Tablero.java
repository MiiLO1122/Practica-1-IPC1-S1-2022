/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ipc1_practica1_.pkg201708550;

import java.util.Scanner;

/**
 *
 * @author miilo
 */
public class Tablero {
    int contadorPremios;
    int OPC = 0;
    int i = 0; //posicion x tablero
    int j = 0; //posicion y tablero
    int x; //dimension x tablero
    int y; //dimension y tablero
    int line;
    int column;
    int contador = 1;
    String user = ""; //nombre de usuario
    String board = ""; //tamaño de tablero
    String jump = "";  //linea superior e inferior del tablero
    int type;   //tamaño de tablero   
    int pts;    //puntos de jugador
    int lifes = 3;  //vidas jugador
    char[][] tablero = new char[x][y];  //espacios tablero
    int[][] posiciones = new int[x][y]; //posiciones del tablero
    Scanner Scan = new Scanner(System.in);//scanner
    String teclado = "";

    public void menu() {
        OPC = 0;
        type = 0;
        pts = 0;
        lifes = 3;
        System.out.println("====MENÚ DE INICIO====");
        System.out.println("1.  Iniciar Juego");
        System.out.println("2.  HIstorial de partidas");
        System.out.println("3.  Salir");
        System.out.print("Seleccione una opción: ");
        String option = Scan.nextLine();
        OPC = Integer.parseInt(option);
        if (OPC == 3) {
            System.out.println("Adios");
            System.exit(0);
        } else {
            while (OPC != 3) {
                if (OPC < 1 || OPC > 3) {
                    System.out.println("Inserte una opcion valida");
                    menu();
                } else {
                    switch (OPC) {
                        case 1:
                            ejecutar();
                            OPC = 3;
                            break;
                        case 2:
                            //Historial de partidas (PENDIENTE)
                            break;
                    }
                }
            }
        }

    }

    public void ejecutar() /*Tablero*/ {
        System.out.print("Ingrese el nombre de usuario: ");
        user = Scan.nextLine();
        while (type != 1 && type != 2) {
            System.out.println("POR FAVOR, INGRESE LOS SIGUIENTES VALORES");
            System.out.print("TABLERO: ");
            board = Scan.nextLine();
            if ("P".equals(board)) {
                type = 1;
            } else if ("G".equals(board)) {
                type = 2;
            } else {
                System.out.println("Seleccione una opcion de tablero valida");
                type = 3;
            }
            switch (type) {
                case 1:
                    x = 5;
                    y = 6;
                    tablero = new char[5][6];
                    posiciones = new int[5][6];
                    jump = "--------";
                    break;
                case 2:
                    x = 10;
                    y = 10;
                    tablero = new char[10][10];
                    posiciones = new int[10][10];
                    jump = "------------";

                    break;
            }
        }
        premios();
        paredes();
        trampas();
        tablero();
        pacman();
        tablero();
        movimientoPacman();
    }

    public void premios() {
        int cantPremios = 0;
        if (type == 1) {
            cantPremios = 12;
        } else if (type == 2) {
            cantPremios = 40;
        }
        System.out.print("PREMIOS [1-" + cantPremios + "]: ");
        String priceNum = Scan.nextLine();
        int prem = Integer.parseInt(priceNum);
        contadorPremios = prem;
        int[] X = new int[prem];
        int[] Y = new int[prem];
        int tipoPremio;
        if (prem > cantPremios || prem < 1) {
            System.out.println("Elija un cantidad de premios valida.");
            premios();
        } else {
            for (i = 0; i < prem; i++) {
                X[i] = (int) (Math.random() * x);
                Y[i] = (int) (Math.random() * y);
                if (posiciones[X[i]][Y[i]] == 0) {
                    tipoPremio = (int) (Math.random() * 2);
                    if (tipoPremio == 0) { //randomizado tipo de premio
                        tablero[X[i]][Y[i]] = '0';
                        posiciones[X[i]][Y[i]] = 1;
                    } else if (tipoPremio == 1) {
                        tablero[X[i]][Y[i]] = '$';
                        posiciones[X[i]][Y[i]] = 2;
                    }
//                    System.out.println(X[i] + "," + Y[i]);
                } else {
                    while (posiciones[X[i]][Y[i]] != 0) {
                        X[i] = (int) (Math.random() * x);
                        Y[i] = (int) (Math.random() * y);
                    }
                    tipoPremio = (int) (Math.random() * 2);
                    if (tipoPremio == 0) { //randomizado tipo de premio
                        tablero[X[i]][Y[i]] = '0';
                        posiciones[X[i]][Y[i]] = 1;
                    } else if (tipoPremio == 1) {
                        tablero[X[i]][Y[i]] = '$';
                        posiciones[X[i]][Y[i]] = 2;
                    }
//                    System.out.println(X[i] + "," + Y[i]);
                }
            }
        }
    }

    public void paredes() {
        int cantPremios = 0;
        if (type == 1) {
            cantPremios = 6;
        } else if (type == 2) {
            cantPremios = 20;
        }
        System.out.print("Paredes [1-" + cantPremios + "]: ");
        String priceNum = Scan.nextLine();
        int prem = Integer.parseInt(priceNum);
        int[] X = new int[prem];
        int[] Y = new int[prem];
        int tipoPremio;
        if (prem > cantPremios || prem < 1) {
            System.out.println("Elija un cantidad de paredes valida.");
            paredes();
        } else {
            for (i = 0; i < prem; i++) {
                X[i] = (int) (Math.random() * x);
                Y[i] = (int) (Math.random() * y);
                if (posiciones[X[i]][Y[i]] == 0) {
                    tablero[X[i]][Y[i]] = 'X';
                    posiciones[X[i]][Y[i]] = 3;
//                    System.out.println(X[i] + "," + Y[i]);
                } else {
                    while (posiciones[X[i]][Y[i]] != 0) {
                        X[i] = (int) (Math.random() * x);
                        Y[i] = (int) (Math.random() * y);
                    }
                    tablero[X[i]][Y[i]] = 'X';
                    posiciones[X[i]][Y[i]] = 3;
//                    System.out.println(X[i] + "," + Y[i]);
                }
            }
        }
    }

    public void trampas() {
        int cantPremios = 0;
        if (type == 1) {
            cantPremios = 6;
        } else if (type == 2) {
            cantPremios = 20;
        }
        System.out.print("Trampas [1-" + cantPremios + "]: ");
        String priceNum = Scan.nextLine();
        int prem = Integer.parseInt(priceNum);
        int[] X = new int[prem];
        int[] Y = new int[prem];
        int tipoPremio;
        if (prem > cantPremios || prem < 1) {
            System.out.println("Elija un cantidad de trampas valida.");
            trampas();
        } else {
            for (i = 0; i < prem; i++) {
                X[i] = (int) (Math.random() * x);
                Y[i] = (int) (Math.random() * y);
                if (posiciones[X[i]][Y[i]] == 0) {
                    tablero[X[i]][Y[i]] = '@';
                    posiciones[X[i]][Y[i]] = 4;
//                    System.out.println(X[i] + "," + Y[i]);
                } else {
                    while (posiciones[X[i]][Y[i]] != 0) {
                        X[i] = (int) (Math.random() * x);
                        Y[i] = (int) (Math.random() * y);
                    }
                    tablero[X[i]][Y[i]] = '@';
                    posiciones[X[i]][Y[i]] = 4;
//                    System.out.println(X[i] + "," + Y[i]);
                }
            }
        }
    }

    public void tablero() {
        System.out.println("-------------------");
        System.out.println("USUARIO: " + user);
        System.out.println("PUNTEO: " + pts);
        System.out.println("VIDAS: " + lifes);
        System.out.println(jump);
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                if (posiciones[i][j] == 0) {
                    tablero[i][j] = ' ';
                }
                if (j == y - 1) {
                    System.out.println(tablero[i][j] + "|");
                } else {
                    if (j == 0) {
                        System.out.print("|" + tablero[i][j]);
                    } else {
                        System.out.print(tablero[i][j]);
                    }
                }
            }
        }
        System.out.println(jump);
    }

    public void pacman() {
        System.out.println("====== ESPECIFICAR TABLERO ======");
        System.out.println("POR FAVOR, INGRESE LA POSICIÓN INICIAL DE JUEGO");
        System.out.print("FILA");
        String fila = Scan.nextLine();
        line = Integer.parseInt(fila);
        System.out.print("COLUMNA");
        String columna = Scan.nextLine();
        column = Integer.parseInt(columna);
        line = line - 1;
        column = column - 1;
        posiciones[line][column] = 5;
        tablero[line][column] = '<';
        tablero();
    }

    public void movimientoPacman() {
        System.out.println("BUENO VAMOS A JUGAR");
        System.out.println("8: Arriba");
        System.out.println("5: Abajo");
        System.out.println("4: Izquierda");
        System.out.println("6: derecha");
        System.out.println("F: pausa");
        System.out.println("");
        teclado = Scan.nextLine();
        if (teclado.equals("f") || teclado.equals("F")) {
            System.out.println("======PAUSA======");
            System.out.println("1. REGRESAR");
            System.out.println("2. TERMINAR PARTIDA");
            String opPausa = Scan.nextLine();
            int op = Integer.parseInt(opPausa);
            switch (op) {
                case 1:
                    System.out.println("----------------------------------------");
                    tablero();
                    movimientoPacman();
                    break;
                case 2:
                    System.out.println("----------------------------------------");
                    System.out.println("ADIOS!");
                    menu();
                    break;
            }
        } else if (teclado.equals("8")) {
            posiciones[line][column] = 0;//limpiar posicion anterior de pacman 
            line--;//posicion nueva de pacman
            tp();
            puntajes();
            posiciones[line][column] = 5;
            tablero[line][column] = '<';
            tablero();
            movimientoPacman();
        } else if (teclado.equals("5")) {
            posiciones[line][column] = 0;
            line++;
            tp();
            puntajes();
            posiciones[line][column] = 5;
            tablero[line][column] = '<';
            tablero();
            movimientoPacman();
        } else if (teclado.equals("4")) {
            posiciones[line][column] = 0;
            column--;
            tp();
            puntajes();
            posiciones[line][column] = 5;
            tablero[line][column] = '<';
            tablero();
            movimientoPacman();
        } else if (teclado.equals("6")) {
            posiciones[line][column] = 0;
            column++;
            tp();
            puntajes();
            posiciones[line][column] = 5;
            tablero[line][column] = '<';
            tablero();
            movimientoPacman();
        }

    }

    public void puntajes() {
        switch (posiciones[line][column]) {
            case 1 -> {
                contadorPremios--;
                if (contadorPremios == 0) {
                    pts = pts + 10;
                    System.out.println("GANASTE PA!");
                    System.out.println("--------------------------------");
                    menu();
                } else {
                    pts = pts + 10;
                    posiciones[line][column] = 5;
                    tablero[line][column] = '<';
                    tablero();
                    movimientoPacman();
                }
            }
            case 2 -> {
                contadorPremios--;
                if (contadorPremios == 0) {
                    pts = pts + 15;
                    System.out.println("GANASTE PA!");
                    System.out.println("--------------------------------");
                    menu();
                } else {
                    pts = pts + 15;
                    posiciones[line][column] = 5;
                    tablero[line][column] = '<';
                    tablero();
                    movimientoPacman();
                }
            }
            case 4 -> {
                lifes--;
                posiciones[line][column] = 5;
                tablero[line][column] = '<';
                if (lifes < 0) {
                    System.out.println("FIN DE LA PARTIDA!");
                    System.out.println(user + " a obtenido " + pts + " puntos");
                    menu();
                } else {
                    tablero();
                    movimientoPacman();
                }
            }
            default -> {
            }
        }
    }

    public void tp() {
        if (type == 1) {
            if (column < 0 && teclado.equals("4")) {
                column = 5;
                puntajes();
            } else if (column > 5 && teclado.equals("6")) {
                column = 0;
                puntajes();
            } else if (line < 0 && teclado.equals("8")) {
                line = 4;
                puntajes();
            } else if (line > 4 && teclado.equals("5")) {
                line = 0;
                puntajes();
            }
        } else if (type == 2) {
            if (column < 0 && teclado.equals("4")) {
                column = 9;
                puntajes();
            } else if (column > 9 && teclado.equals("6")) {
                column = 0;
                puntajes();
            } else if (line < 0 && teclado.equals("8")) {
                line = 9;
                puntajes();
            } else if (line > 9 && teclado.equals("5")) {
                line = 0;
                puntajes();
            }
        }

    }
}
