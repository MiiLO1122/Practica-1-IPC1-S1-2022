/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ipc1_practica1_.pkg201708550;

import java.util.Scanner;

/**
 *
 * @author miilo
 */
public class Tablero {

    int counter = 0;
    int i = 0;
    int j = 0;
    int x;
    int y;
    String user = "";
    String board = "";
    String jump = "";
    int type;
    int prices;
    int walls;
    int traps;
    String simplePrice = "0";
    String specialPrice = "$";
    String wall = "X";
    String ghost = "@";
    String pacman = "<";
    int pts;
    int lifes = 3;
    int[][] boardPossitions = new int[x][y];
    String space = "    ";

    public void menu() {
        System.out.println("====MENÚ DE INICIO ");
        System.out.println("1.  Iniciar Juego");
        System.out.println("2.  HIstorial de partidas");
        System.out.println("3.  Salir");
        Scanner opc = new Scanner(System.in);
        String option = opc.nextLine();
        int OPC = Integer.parseInt(option);
        if (OPC == 3) {
            System.out.println("Adios");
        } else {
            while (OPC != 3) {
                if (OPC < 1 || OPC > 3) {
                    System.out.println("Inserte una opcion valida");
                    menu();
                } else {
                    switch (OPC) {
                        case 1:
                            ejecutar();
                            OPC = 3;
                            break;
                        case 2:
                            //Historial de partidas (PENDIENTE)
                            break;
                    }
                }
            }
        }

    }

    public void ejecutar() /*Tablero*/ {
        System.out.print("Ingrese el nombre de usuario: ");
        Scanner SignUser = new Scanner(System.in);
        user = SignUser.nextLine();
        while (type != 1 && type != 2) {
            System.out.println("POR FAVOR, INGRESE LOS SIGUIENTES VALORES");
            System.out.print("TABLERO: ");
            Scanner BoardType = new Scanner(System.in);
            board = SignUser.nextLine();
            if ("P".equals(board)) {
                type = 1;
            } else if ("G".equals(board)) {
                type = 2;
            } else {
                System.out.println("Seleccione una opcion de tablero valida");
                type = 3;
            }
            switch (type) {
                case 1:
                    x = 5;
                    y = 6;
                    jump = "--------";
                    break;
                case 2:
                    x = 10;
                    y = 10;
                    jump = "------------";

                    break;
            }
        }
        premios();
        paredes();
        trampas();
        tablero();
    }

    public void premios() {
        int priceQty = 0;
        if (type == 1) {
            priceQty = 12;
        } else if (type == 2) {
            priceQty = 40;
        }
        System.out.print("PREMIOS [1-" + priceQty + "]: ");
        Scanner inserPrice = new Scanner(System.in);
        String priceNum = inserPrice.nextLine();
        int prem = Integer.parseInt(priceNum);
        if (prem < 1 || prem > priceQty) {
            System.out.println("Ingrese una opcion valida");
            premios();
        } else {
            int X = (int) (Math.random() * 5);
            int Y = (int) (Math.random() * 5);
            if (X == i && Y == j) {
                int priceType = (int) (Math.random() * 2);
                if (priceType == 0) {
                    space = simplePrice;
                } else {
                    space = specialPrice;
                }
            } else {
                X = (int) (Math.random() * 5 + 1);
                Y = (int) (Math.random() * 5 + 1);

            }
        }

    }

    public void paredes() {
        int wallQty = 0;
        if (type == 1) {
            wallQty = 6;
        } else if (type == 2) {
            wallQty = 20;
        }
        System.out.print("Paredes [1-" + wallQty + "]: ");
        Scanner inserWalls = new Scanner(System.in);
        String priceNum = inserWalls.nextLine();
        int prem = Integer.parseInt(priceNum);
        if (prem < 1 || prem > wallQty) {
            System.out.println("Ingrese una opcion valida");
            paredes();
        } else {

        }

    }

    public void trampas() {
        int trapsQty = 0;
        if (type == 1) {
            trapsQty = 6;
        } else if (type == 2) {
            trapsQty = 20;
        }
        System.out.print("Trampas [1-" + trapsQty + "]: ");
        Scanner inserTraps = new Scanner(System.in);
        String priceNum = inserTraps.nextLine();
        int prem = Integer.parseInt(priceNum);
        if (prem < 1 || prem > trapsQty) {
            System.out.println("Ingrese una opcion valida");
            trampas();
        } else {
            //randomizado
        }

    }

    public void tablero() {
        System.out.println("-------------------");
        System.out.println("USUARIO: " + user);
        System.out.println("PUNTEO: " + pts);
        System.out.println("VIDAS: " + lifes);
        System.out.println(jump);
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                if (j == 0) {
                    System.out.print("|" + space);
                } else {
                    System.out.print(space);
                }
            }
            System.out.println("|");
        }
        System.out.println(jump);
    }
}
