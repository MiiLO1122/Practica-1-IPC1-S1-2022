/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ipc1_practica1_.pkg201708550;

/**
 *
 * @author miilo
 */
public class IPC1_Practica1_201708550 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Tablero pacman = new Tablero();
        pacman.menu();
    }

}
