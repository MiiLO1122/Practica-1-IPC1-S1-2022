/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ipc1_practica1_.pkg201708550;

import java.util.Scanner;

/**
 *
 * @author miilo
 */
public class Tablero {

    int i = 0; //posicion x tablero
    int j = 0; //posicion y tablero
    int x; //dimension x tablero
    int y; //dimension y tablero
    String user = ""; //nombre de usuario
    String board = ""; //tamaño de tablero
    String jump = "";  //linea superior e inferior del tablero
    int type;   //tamaño de tablero   
    int pts;    //puntos de jugador
    int lifes = 3;  //vidas jugador
    int premios;
    char[][] tablero = new char[x][y];  //espacios tablero1
    char espacio = ' '; //espacio de tablero

    public void menu() {
        System.out.println("====MENÚ DE INICIO ");
        System.out.println("1.  Iniciar Juego");
        System.out.println("2.  HIstorial de partidas");
        System.out.println("3.  Salir");
        Scanner opc = new Scanner(System.in);
        String option = opc.nextLine();
        int OPC = Integer.parseInt(option);
        if (OPC == 3) {
            System.out.println("Adios");
        } else {
            while (OPC != 3) {
                if (OPC < 1 || OPC > 3) {
                    System.out.println("Inserte una opcion valida");
                    menu();
                } else {
                    switch (OPC) {
                        case 1:
                            ejecutar();
                            OPC = 3;
                            break;
                        case 2:
                            //Historial de partidas (PENDIENTE)
                            break;
                    }
                }
            }
        }

    }

    public void ejecutar() /*Tablero*/ {
        System.out.print("Ingrese el nombre de usuario: ");
        Scanner SignUser = new Scanner(System.in);
        user = SignUser.nextLine();
        while (type != 1 && type != 2) {
            System.out.println("POR FAVOR, INGRESE LOS SIGUIENTES VALORES");
            System.out.print("TABLERO: ");
            Scanner BoardType = new Scanner(System.in);
            board = SignUser.nextLine();
            if ("P".equals(board)) {
                type = 1;
            } else if ("G".equals(board)) {
                type = 2;
            } else {
                System.out.println("Seleccione una opcion de tablero valida");
                type = 3;
            }
            switch (type) {
                case 1:
                    x = 5;
                    y = 6;
                    tablero = new char[5][6];
                    jump = "--------";
                    break;
                case 2:
                    x = 10;
                    y = 10;
                    tablero = new char[10][10];
                    jump = "------------";

                    break;
            }
        }
        premios();
        paredes();
        trampas();
        tablero();
    }

    public void premios() {

        int cantPremios = 0;
        if (type == 1) {
            cantPremios = 12;
        } else if (type == 2) {
            cantPremios = 40;
        }
        System.out.print("PREMIOS [1-" + cantPremios + "]: ");
        Scanner inserPrice = new Scanner(System.in);
        String priceNum = inserPrice.nextLine();
        int prem = Integer.parseInt(priceNum);
        int X;
        int Y;
        if (prem < 1 || prem > cantPremios) {
            System.out.println("Ingrese una cantidad de premios valida");
            premios();
        } else {
            for (int h = 0; h < prem; i++) {
                X = (int) (Math.random() * x);
                Y = (int) (Math.random() * y);
                for (int i = 0; i < x; i++) {
                    for (int j = 0; j < y; j++) {
                        if (X == i || Y == j) {
                            espacio = '$';
                        }else{
                            espacio = ' ';
                        }
                    }
                }

            }
        }
    }

    public void paredes() {
    }

    public void trampas() {
    }

    public void tablero() {
        System.out.println("-------------------");
        System.out.println("USUARIO: " + user);
        System.out.println("PUNTEO: " + pts);
        System.out.println("VIDAS: " + lifes);
        System.out.println(jump);
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                tablero[i][j] = espacio;
                if (j == y - 1) {
                    System.out.println(tablero[i][j] + "|");
                } else {
                    if (j == 0) {
                        System.out.print("|" + tablero[i][j]);
                    } else {
                        System.out.print(tablero[i][j]);
                    }
                }
            }
        }
        System.out.println(jump);
    }
}
